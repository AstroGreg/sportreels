import React, { useEffect, useRef, useCallback, useState } from "react";
import Home from "./components/Home/home";


function App() {
  return (
    <Home /> 
  );
}

export default App;
